var searchData=
[
  ['transfer_20commands',['Transfer Commands',['../group___d_a_p__transfer__gr.html',1,'']]],
  ['target_5fdevice_5ffixed',['TARGET_DEVICE_FIXED',['../group___d_a_p___config___debug__gr.html#ga792651aa4035a7ad712c6bb201db8a6a',1,'DAP_config.h']]]
];
